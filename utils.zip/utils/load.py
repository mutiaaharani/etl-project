from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from sqlalchemy import create_engine


def save_to_csv(df, filename="products.csv"):
    try:
        df.to_csv(filename, index=False)
        print("CSV saved!")
    except Exception as e:
        print(f"Error save CSV: {e}")


def save_to_sheets(df, spreadsheet_id):
    try:
        creds = Credentials.from_service_account_file(
            "google-sheets-api.json",
            scopes=["https://www.googleapis.com/auth/spreadsheets"]
        )

        service = build("sheets", "v4", credentials=creds)

        df_copy = df.copy()
        if "timestamp" in df_copy.columns:
            df_copy["timestamp"] = df_copy["timestamp"].astype(str)

        values = [df_copy.columns.tolist()] + df_copy.values.tolist()

        body = {"values": values}

        service.spreadsheets().values().update(
            spreadsheetId=spreadsheet_id,
            range="Sheet1!A1",
            valueInputOption="RAW",
            body=body
        ).execute()

        print("Google Sheets updated!")

    except Exception as e:
        print(f"Error save Sheets: {e}")


def save_to_postgres(df):
    try:
        DB_USER = "postgres"
        DB_PASS = "postgres"
        DB_HOST = "localhost"
        DB_PORT = "5432"
        DB_NAME = "etl_db"

        engine = create_engine(
            f"postgresql+psycopg2://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        )

        df.to_sql("products", engine, if_exists="replace", index=False)

        print("PostgreSQL saved!")

    except Exception:
        print("PostgreSQL skipped (not connected)")