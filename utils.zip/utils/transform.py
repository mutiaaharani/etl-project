import re

import pandas as pd


def clean_price(price):
    if pd.isna(price):
        return None

    price = str(price)
    if "Unavailable" in price:
        return None

    value = re.findall(r"\d+\.\d+|\d+", price)
    return float(value[0]) * 16000 if value else None


def clean_rating(rating):
    if pd.isna(rating):
        return None

    rating = str(rating)
    if "Invalid" in rating or "Not Rated" in rating:
        return None

    value = re.findall(r"\d+\.\d+|\d+", rating)
    return float(value[0]) if value else None


def clean_colors(colors):
    if pd.isna(colors):
        return None

    value = re.findall(r"\d+", str(colors))
    return int(value[0]) if value else None


def clean_size(size):
    if pd.isna(size):
        return None
    return str(size).replace("Size:", "").strip()


def clean_gender(gender):
    if pd.isna(gender):
        return None
    return str(gender).replace("Gender:", "").strip()

def transform_data(data):
    try:
        df = pd.DataFrame(data)

        print("Sebelum transform:", len(df))

        df.index = list(range(1, len(df) + 1))

        df["Price"] = df["Price"].apply(clean_price)
        df["Rating"] = df["Rating"].apply(clean_rating)
        df["Colors"] = df["Colors"].apply(clean_colors)
        df["Size"] = df["Size"].apply(clean_size)
        df["Gender"] = df["Gender"].apply(clean_gender)

        df = df.dropna(subset=["Price", "Rating", "Colors"])

        df.index = df.index - 1  # biar 1–999

        print("Sesudah transform:", len(df))

        if "timestamp" in df.columns:
            df = df.drop(columns=["timestamp"])

        df["Price"] = df["Price"].astype(float)
        df["Rating"] = df["Rating"].astype(float)
        df["Colors"] = df["Colors"].astype("Int64")

        return df

    except Exception as e:
        print("Error transform:", e)
        return pd.DataFrame()