import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}


def fetch_page(url):
    session = requests.Session()
    response = session.get(url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    return response.content


def scrape_page(page, retries=5):
    url = "https://fashion-studio.dicoding.dev/" if page == 1 else f"https://fashion-studio.dicoding.dev/page{page}"

    for attempt in range(retries):
        try:
            response = requests.get(url, headers=HEADERS, timeout=10)

            if response.status_code == 200:
                soup = BeautifulSoup(response.text, "html.parser")
                products = soup.find_all("div", class_="collection-card")

                if len(products) < 20:
                    print(f"Data kurang di page {page}, retry...")
                    time.sleep(2)
                    continue

                data = []

                for product in products:
                    title_tag = product.find("h3", class_="product-title")
                    if not title_tag:
                        continue

                    title = title_tag.text.strip()

                    price_span = product.find("span", class_="price")
                    price_p = product.find("p", class_="price")

                    if price_span and price_span.text.strip():
                        price = price_span.text.strip()
                    elif price_p and price_p.text.strip():
                        price = price_p.text.strip()
                    else:
                        price = "Price Unavailable"

                    details = product.find_all("p")
                    rating = details[0].text.strip() if len(details) > 0 else ""
                    colors = details[1].text.strip() if len(details) > 1 else ""
                    size = details[2].text.strip() if len(details) > 2 else ""
                    gender = details[3].text.strip() if len(details) > 3 else ""

                    data.append({
                        "Title": title,
                        "Price": price,
                        "Rating": rating,
                        "Colors": colors,
                        "Size": size,
                        "Gender": gender,
                        "timestamp": datetime.now()
                    })

                return data

        except Exception:
            print(f"Retry {attempt + 1} page {page}...")
            time.sleep(2)

    print(f"Gagal total page {page}")
    return []


def scrape_all():
    all_data = []

    for page in range(1, 51):
        print(f"Scraping page {page}...")
        data = scrape_page(page)
        all_data.extend(data)
        time.sleep(1)

    print(f"TOTAL DATA HASIL SCRAPING: {len(all_data)}")
    return all_data