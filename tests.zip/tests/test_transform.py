import pandas as pd
from utils.transform import clean_price, clean_colors, transform_data


def test_clean_price():
    assert clean_price("$10.00") == 160000


def test_clean_colors():
    assert clean_colors("3 Colors") == 3


def test_transform_data():
    data = [
        {
            "Title": "Test Product",
            "Price": "$10",
            "Rating": "4.5",
            "Colors": "3 Colors",
            "Size": "Size: M",
            "Gender": "Gender: Men"
        }
    ]

    df = transform_data(data)

    # Data tidak kosong
    assert not df.empty

    # Cek hasil transform
    assert df["Price"].iloc[0] == 160000
    assert df["Rating"].iloc[0] == 4.5
    assert df["Colors"].iloc[0] == 3
    assert df["Size"].iloc[0] == "M"
    assert df["Gender"].iloc[0] == "Men"


def test_transform_drop_invalid():
    data = [
        {
            "Title": "Bad Product",
            "Price": "Price Unavailable",
            "Rating": "Invalid Rating",
            "Colors": "No Colors",
            "Size": "Size: L",
            "Gender": "Gender: Women"
        }
    ]

    df = transform_data(data)

    assert df.empty